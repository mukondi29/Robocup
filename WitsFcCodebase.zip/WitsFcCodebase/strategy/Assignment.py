import numpy as np

def role_assignment(teammate_positions, formation_positions): 
    all_preferences = [list() for _ in range(10)]

    # Player preferences (0 to 4)
    for i in range(5):
        distance_dict = {}
        for j in range(5):
            my_position = teammate_positions[i]
            formation = formation_positions[j]
            distance = np.linalg.norm(my_position - formation)
            distance_dict[j] = distance
        sorted_keys = sorted(distance_dict, key=distance_dict.get)
        all_preferences[i] = sorted_keys  # Player i's preferences (formation indices)

    # Formation preferences (5 to 9)
    for i in range(5):
        distance_dict = {}
        for j in range(5):
            formation = formation_positions[i]
            player = teammate_positions[j]
            distance = np.linalg.norm(formation - player)
            distance_dict[j] = distance
        sorted_keys = sorted(distance_dict, key=distance_dict.get)
        all_preferences[i + 5] = sorted_keys  # Formation i's preferences (player indices)

    # Helper to check if formation f prefers p1 over p2
    def formationPrefersP1OverP(preference_list, p1, p2):
        for player in preference_list:
            if player == p1:
                return True
            if player == p2:
                return False
        return False  # Should not happen

    # Stable Marriage Algorithm
    def stableMarriage():
        N = 5  # Number of players/formations
        fPartner = [-1] * N  # formation index -> player index
        pFree = [False] * N  # player index -> whether matched
        pNext = [0] * N  # which formation each player proposes to next
        freeCount = N

        while freeCount > 0:
            for p in range(N):
                if pFree[p]:
                    continue
                f = all_preferences[p][pNext[p]]  # Next preferred formation
                pNext[p] += 1

                if fPartner[f] == -1:
                    fPartner[f] = p
                    pFree[p] = True
                    freeCount -= 1
                else:
                    current = fPartner[f]
                    if not formationPrefersP1OverP(all_preferences[f + 5], current, p):
                        fPartner[f] = p
                        pFree[p] = True
                        pFree[current] = False
        return fPartner

    fPartner = stableMarriage()  # formation index -> player index

    # Convert to player -> formation mapping
    our_dict = {player: formation for formation, player in enumerate(fPartner)}

    # Return the dictionary in the expected format:
    point_preferences = {}
    for player_index in range(5):
        formation_index = our_dict[player_index]
        location = formation_positions[formation_index]
        # UNUMs are 1-based (1–5)
        point_preferences[player_index + 1] = location

    return point_preferences
